import { NextRequest, NextResponse } from 'next/server';
import { generateDailyDigest, sendDigestToChannel } from '@/lib/bot/telegram-service';
import { newsService } from '@/lib/bot/news-service';
import { db } from '@/lib/db';

// GET - получить историю дайджестов
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const action = searchParams.get('action');
    const id = searchParams.get('id');
    
    // Получить конкретный дайджест
    if (action === 'get' && id) {
      const digest = await db.dailyDigest.findUnique({
        where: { id },
        include: {
          newsItems: true,
          pendingPosts: true
        }
      });
      
      if (!digest) {
        return NextResponse.json({ error: 'Digest not found' }, { status: 404 });
      }
      
      return NextResponse.json({ digest });
    }
    
    // Получить последний дайджест
    if (action === 'latest') {
      const digest = await db.dailyDigest.findFirst({
        orderBy: { createdAt: 'desc' },
        include: {
          newsItems: true
        }
      });
      
      return NextResponse.json({ digest });
    }
    
    // Получить список дайджестов
    const digests = await db.dailyDigest.findMany({
      orderBy: { createdAt: 'desc' },
      take: 30,
      select: {
        id: true,
        date: true,
        isSent: true,
        sentAt: true,
        isPublished: true,
        publishedAt: true,
        createdAt: true
      }
    });
    
    return NextResponse.json({ digests });
  } catch (error) {
    console.error('Error getting digests:', error);
    return NextResponse.json(
      { error: 'Failed to get digests' },
      { status: 500 }
    );
  }
}

// POST - сгенерировать или отправить дайджест
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const action = body.action;
    
    // Сгенерировать превью дайджеста
    if (action === 'preview') {
      const digest = await generateDailyDigest();
      
      return NextResponse.json({
        success: true,
        content: digest,
        length: digest.length
      });
    }
    
    // Найти новости без генерации полного дайджеста
    if (action === 'search') {
      const count = body.count || 10;
      const news = await newsService.searchRealEstateNews(count);
      
      return NextResponse.json({
        success: true,
        count: news.length,
        news: news.map(item => ({
          title: item.title,
          summary: item.summary,
          source: item.source,
          sourceName: item.sourceName,
          category: item.category
        }))
      });
    }
    
    // Отправить дайджест в канал
    if (action === 'send') {
      const content = body.content;
      const result = await sendDigestToChannel(content);
      
      if (result.success) {
        return NextResponse.json({
          success: true,
          messageId: result.messageId
        });
      } else {
        return NextResponse.json(
          { error: result.error },
          { status: 500 }
        );
      }
    }
    
    // Сохранить отредактированный дайджест
    if (action === 'save') {
      const { content, originalDigestId } = body;
      
      const digest = await db.dailyDigest.create({
        data: {
          content,
          // Связываем с оригиналом если есть
          ...(originalDigestId && {
            pendingPosts: {
              create: {
                originalContent: content,
                editedContent: content,
                dailyDigestId: originalDigestId
              }
            }
          })
        }
      });
      
      return NextResponse.json({
        success: true,
        digestId: digest.id
      });
    }
    
    return NextResponse.json(
      { error: 'Invalid action' },
      { status: 400 }
    );
  } catch (error) {
    console.error('Error processing digest:', error);
    return NextResponse.json(
      { error: 'Failed to process digest' },
      { status: 500 }
    );
  }
}

// PUT - обновить дайджест (редактирование)
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, content, comment, status } = body;
    
    if (!id) {
      return NextResponse.json(
        { error: 'Digest ID required' },
        { status: 400 }
      );
    }
    
    const updateData: Record<string, unknown> = {};
    
    if (content) updateData.content = content;
    if (status) {
      updateData.isPublished = status === 'published';
      if (status === 'published') {
        updateData.publishedAt = new Date();
      }
    }
    
    const digest = await db.dailyDigest.update({
      where: { id },
      data: updateData
    });
    
    // Обновляем или создаём pending post с комментарием
    if (comment) {
      await db.pendingPost.upsert({
        where: { dailyDigestId: id },
        update: { comment },
        create: {
          dailyDigestId: id,
          originalContent: digest.content,
          comment
        }
      });
    }
    
    return NextResponse.json({
      success: true,
      digest
    });
  } catch (error) {
    console.error('Error updating digest:', error);
    return NextResponse.json(
      { error: 'Failed to update digest' },
      { status: 500 }
    );
  }
}

import { NextRequest, NextResponse } from 'next/server';
import { handleWebhook, initWebhook, setBotCommands, getBotSettings, getBot } from '@/lib/bot/telegram-service';

// POST - обработка webhook от Telegram
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    // Обрабатываем update от Telegram
    await handleWebhook(body);
    
    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error('Webhook error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// GET - проверка статуса и инициализация webhook
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const action = searchParams.get('action');
    const token = searchParams.get('token');
    
    // Установка webhook
    if (action === 'set_webhook') {
      const settings = await getBotSettings();
      const botToken = token || settings?.botToken;
      
      if (!botToken) {
        return NextResponse.json(
          { error: 'Bot token not provided' },
          { status: 400 }
        );
      }

      // Получаем базовый URL
      const host = request.headers.get('host') || 'localhost:3000';
      const protocol = request.headers.get('x-forwarded-proto') || 'https';
      const webhookUrl = `${protocol}://${host}/api/telegram/webhook`;
      
      // Инициализируем бота с токеном
      const bot = await getBot(botToken);
      if (!bot) {
        return NextResponse.json(
          { error: 'Failed to initialize bot' },
          { status: 500 }
        );
      }
      
      const success = await initWebhook(webhookUrl);
      
      if (success) {
        // Устанавливаем команды
        await setBotCommands();
        
        return NextResponse.json({
          success: true,
          webhookUrl,
          message: 'Webhook установлен успешно'
        });
      } else {
        return NextResponse.json(
          { error: 'Failed to set webhook' },
          { status: 500 }
        );
      }
    }
    
    // Проверка статуса
    if (action === 'status') {
      const settings = await getBotSettings();
      
      return NextResponse.json({
        configured: !!settings?.botToken,
        hasChannel: !!settings?.channelId,
        channelName: settings?.channelName,
        sendTime: settings?.sendTime,
        timezone: settings?.timezone,
        isActive: settings?.isActive
      });
    }

    return NextResponse.json({
      message: 'Telegram Webhook Endpoint',
      actions: ['set_webhook', 'status']
    });
  } catch (error) {
    console.error('Error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

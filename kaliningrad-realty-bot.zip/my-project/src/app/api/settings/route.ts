import { NextRequest, NextResponse } from 'next/server';
import { saveBotSettings, getBotSettings } from '@/lib/bot/telegram-service';

// GET - получить текущие настройки
export async function GET() {
  try {
    const settings = await getBotSettings();
    
    return NextResponse.json({
      settings: settings ? {
        botToken: settings.botToken ? '••••••••' + settings.botToken.slice(-6) : '',
        hasToken: !!settings.botToken,
        channelId: settings.channelId,
        channelName: settings.channelName,
        channelUsername: settings.channelUsername,
        isActive: settings.isActive,
        sendTime: settings.sendTime,
        timezone: settings.timezone
      } : null
    });
  } catch (error) {
    console.error('Error getting settings:', error);
    return NextResponse.json(
      { error: 'Failed to get settings' },
      { status: 500 }
    );
  }
}

// POST - сохранить настройки
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    // Валидация
    if (body.botToken !== undefined && body.botToken && !body.botToken.startsWith('•')) {
      // Новый токен
      if (!body.botToken.match(/^\d+:[A-Za-z0-9_-]{35}$/)) {
        return NextResponse.json(
          { error: 'Invalid bot token format' },
          { status: 400 }
        );
      }
    }

    const settings = await saveBotSettings({
      botToken: body.botToken && !body.botToken.startsWith('•') ? body.botToken : undefined,
      channelId: body.channelId,
      channelName: body.channelName,
      channelUsername: body.channelUsername,
      isActive: body.isActive,
      sendTime: body.sendTime,
      timezone: body.timezone
    });

    return NextResponse.json({
      success: true,
      settings: {
        hasToken: !!settings.botToken,
        channelId: settings.channelId,
        channelName: settings.channelName,
        channelUsername: settings.channelUsername,
        isActive: settings.isActive,
        sendTime: settings.sendTime,
        timezone: settings.timezone
      }
    });
  } catch (error) {
    console.error('Error saving settings:', error);
    return NextResponse.json(
      { error: 'Failed to save settings' },
      { status: 500 }
    );
  }
}

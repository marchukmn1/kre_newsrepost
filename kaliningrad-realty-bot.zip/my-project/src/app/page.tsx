'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { 
  Building2, 
  Bot, 
  Settings, 
  Send, 
  Clock, 
  Check, 
  X, 
  Loader2, 
  RefreshCw,
  ExternalLink,
  Eye,
  Edit3,
  Newspaper,
  Calendar
} from 'lucide-react';
import { Separator } from '@/components/ui/separator';

// Типы
interface BotSettings {
  hasToken: boolean;
  channelId?: string;
  channelName?: string;
  channelUsername?: string;
  isActive: boolean;
  sendTime: string;
  timezone: string;
}

interface Digest {
  id: string;
  date: string;
  content?: string;
  isSent: boolean;
  sentAt?: string;
  isPublished: boolean;
  publishedAt?: string;
  createdAt: string;
}

export default function HomePage() {
  // Состояния
  const [settings, setSettings] = useState<BotSettings | null>(null);
  const [botToken, setBotToken] = useState('');
  const [channelUsername, setChannelUsername] = useState('');
  const [sendTime, setSendTime] = useState('08:00');
  const [isActive, setIsActive] = useState(true);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [previewContent, setPreviewContent] = useState('');
  const [editedContent, setEditedContent] = useState('');
  const [comment, setComment] = useState('');
  const [digests, setDigests] = useState<Digest[]>([]);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [activeTab, setActiveTab] = useState('settings');

  // Загрузка данных
  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      // Загружаем настройки
      const settingsRes = await fetch('/api/settings');
      const settingsData = await settingsRes.json();
      if (settingsData.settings) {
        setSettings(settingsData.settings);
        setChannelUsername(settingsData.settings.channelUsername || '');
        setSendTime(settingsData.settings.sendTime || '08:00');
        setIsActive(settingsData.settings.isActive ?? true);
      }

      // Загружаем историю
      const digestRes = await fetch('/api/digest');
      const digestData = await digestRes.json();
      setDigests(digestData.digests || []);
    } catch (error) {
      showMessage('error', 'Ошибка загрузки данных');
    } finally {
      setIsLoading(false);
    }
  };

  // Сохранение настроек
  const saveSettings = async () => {
    setIsSaving(true);
    try {
      const body: Record<string, unknown> = {
        channelUsername,
        sendTime,
        isActive
      };
      
      if (botToken && !botToken.startsWith('•')) {
        body.botToken = botToken;
      }

      const res = await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });

      const data = await res.json();
      
      if (data.success) {
        setSettings(data.settings);
        showMessage('success', 'Настройки сохранены');
        setBotToken('');
      } else {
        showMessage('error', data.error || 'Ошибка сохранения');
      }
    } catch {
      showMessage('error', 'Ошибка соединения');
    } finally {
      setIsSaving(false);
    }
  };

  // Установка webhook
  const setWebhook = async () => {
    if (!settings?.hasToken && !botToken) {
      showMessage('error', 'Сначала укажите токен бота');
      return;
    }

    setIsSaving(true);
    try {
      const res = await fetch(
        `/api/telegram/webhook?action=set_webhook${botToken ? `&token=${botToken}` : ''}`
      );
      const data = await res.json();
      
      if (data.success) {
        showMessage('success', `Webhook установлен: ${data.webhookUrl}`);
      } else {
        showMessage('error', data.error || 'Ошибка установки webhook');
      }
    } catch {
      showMessage('error', 'Ошибка соединения');
    } finally {
      setIsSaving(false);
    }
  };

  // Генерация превью
  const generatePreview = async () => {
    setIsGenerating(true);
    try {
      const res = await fetch('/api/digest', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'preview' })
      });
      const data = await res.json();
      
      if (data.success) {
        setPreviewContent(data.content);
        setEditedContent(data.content);
        showMessage('success', 'Подборка сгенерирована');
      } else {
        showMessage('error', 'Ошибка генерации');
      }
    } catch {
      showMessage('error', 'Ошибка соединения');
    } finally {
      setIsGenerating(false);
    }
  };

  // Отправка в канал
  const sendToChannel = async (content?: string) => {
    if (!settings?.channelId) {
      showMessage('error', 'Сначала настройте канал');
      return;
    }

    setIsSending(true);
    try {
      const res = await fetch('/api/digest', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          action: 'send',
          content: content || editedContent || previewContent
        })
      });
      const data = await res.json();
      
      if (data.success) {
        showMessage('success', 'Подборка отправлена в канал');
        loadData();
      } else {
        showMessage('error', data.error || 'Ошибка отправки');
      }
    } catch {
      showMessage('error', 'Ошибка соединения');
    } finally {
      setIsSending(false);
    }
  };

  // Показать сообщение
  const showMessage = (type: 'success' | 'error', text: string) => {
    setMessage({ type, text });
    setTimeout(() => setMessage(null), 5000);
  };

  // Форматирование даты
  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('ru-RU', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100">
        <Loader2 className="h-8 w-8 animate-spin text-indigo-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b sticky top-0 z-10">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="bg-indigo-600 p-2 rounded-xl">
                <Building2 className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">
                  Калининград Недвижимость
                </h1>
                <p className="text-sm text-gray-500">
                  Telegram Bot Manager
                </p>
              </div>
            </div>
            <Badge 
              variant={settings?.hasToken ? 'default' : 'secondary'}
              className={settings?.hasToken ? 'bg-green-100 text-green-800' : ''}
            >
              {settings?.hasToken ? (
                <><Check className="h-3 w-3 mr-1" /> Настроен</>
              ) : (
                <><X className="h-3 w-3 mr-1" /> Не настроен</>
              )}
            </Badge>
          </div>
        </div>
      </header>

      {/* Message */}
      {message && (
        <div className={`mx-auto max-w-6xl px-4 pt-4`}>
          <div className={`p-4 rounded-lg ${
            message.type === 'success' 
              ? 'bg-green-100 text-green-800 border border-green-200' 
              : 'bg-red-100 text-red-800 border border-red-200'
          }`}>
            {message.text}
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 py-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="bg-white/80 backdrop-blur-sm">
            <TabsTrigger value="settings" className="gap-2">
              <Settings className="h-4 w-4" />
              Настройки
            </TabsTrigger>
            <TabsTrigger value="digest" className="gap-2">
              <Newspaper className="h-4 w-4" />
              Подборка
            </TabsTrigger>
            <TabsTrigger value="history" className="gap-2">
              <Calendar className="h-4 w-4" />
              История
            </TabsTrigger>
          </TabsList>

          {/* Settings Tab */}
          <TabsContent value="settings">
            <div className="grid md:grid-cols-2 gap-6">
              {/* Bot Token */}
              <Card className="bg-white/90 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Bot className="h-5 w-5 text-indigo-600" />
                    Telegram Bot
                  </CardTitle>
                  <CardDescription>
                    Настройка подключения к Telegram
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="token">Токен бота</Label>
                    <Input
                      id="token"
                      type="password"
                      placeholder={settings?.hasToken ? '••••••••••••••••' : '123456:ABC-DEF...'}
                      value={botToken}
                      onChange={(e) => setBotToken(e.target.value)}
                    />
                    <p className="text-xs text-gray-500">
                      Получите токен у @BotFather в Telegram
                    </p>
                  </div>
                  
                  <Button 
                    onClick={setWebhook} 
                    disabled={isSaving}
                    className="w-full"
                  >
                    {isSaving ? (
                      <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    ) : (
                      <RefreshCw className="h-4 w-4 mr-2" />
                    )}
                    Установить Webhook
                  </Button>
                </CardContent>
              </Card>

              {/* Channel Settings */}
              <Card className="bg-white/90 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Send className="h-5 w-5 text-indigo-600" />
                    Канал публикации
                  </CardTitle>
                  <CardDescription>
                    Настройка канала для ежедневной рассылки
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="channel">Username канала</Label>
                    <Input
                      id="channel"
                      placeholder="@my_channel"
                      value={channelUsername}
                      onChange={(e) => setChannelUsername(e.target.value)}
                    />
                    <p className="text-xs text-gray-500">
                      Добавьте бота в администраторы канала
                    </p>
                  </div>
                  
                  {settings?.channelName && (
                    <div className="flex items-center gap-2 text-sm text-green-600">
                      <Check className="h-4 w-4" />
                      {settings.channelName}
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Schedule */}
              <Card className="bg-white/90 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Clock className="h-5 w-5 text-indigo-600" />
                    Расписание
                  </CardTitle>
                  <CardDescription>
                    Время автоматической отправки
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="time">Время отправки</Label>
                    <Input
                      id="time"
                      type="time"
                      value={sendTime}
                      onChange={(e) => setSendTime(e.target.value)}
                    />
                    <p className="text-xs text-gray-500">
                      Часовой пояс: Europe/Kaliningrad (UTC+2)
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Status */}
              <Card className="bg-white/90 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Settings className="h-5 w-5 text-indigo-600" />
                    Статус
                  </CardTitle>
                  <CardDescription>
                    Активность бота
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="active">Бот активен</Label>
                    <Switch
                      id="active"
                      checked={isActive}
                      onCheckedChange={setIsActive}
                    />
                  </div>
                  
                  <Separator />
                  
                  <Button 
                    onClick={saveSettings} 
                    disabled={isSaving}
                    className="w-full"
                  >
                    {isSaving ? (
                      <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    ) : (
                      <Check className="h-4 w-4 mr-2" />
                    )}
                    Сохранить настройки
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Digest Tab */}
          <TabsContent value="digest">
            <div className="grid lg:grid-cols-2 gap-6">
              {/* Preview */}
              <Card className="bg-white/90 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Eye className="h-5 w-5 text-indigo-600" />
                    Предпросмотр
                  </CardTitle>
                  <CardDescription>
                    Сгенерированная подборка новостей
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Button 
                    onClick={generatePreview} 
                    disabled={isGenerating}
                    className="w-full"
                  >
                    {isGenerating ? (
                      <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    ) : (
                      <RefreshCw className="h-4 w-4 mr-2" />
                    )}
                    Сгенерировать подборку
                  </Button>

                  {previewContent && (
                    <div className="bg-gray-50 rounded-lg p-4 max-h-96 overflow-y-auto">
                      <pre className="text-sm whitespace-pre-wrap font-sans">
                        {previewContent}
                      </pre>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Editor */}
              <Card className="bg-white/90 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Edit3 className="h-5 w-5 text-indigo-600" />
                    Редактор
                  </CardTitle>
                  <CardDescription>
                    Отредактируйте перед публикацией
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Textarea
                    placeholder="Сгенерируйте подборку для редактирования..."
                    value={editedContent}
                    onChange={(e) => setEditedContent(e.target.value)}
                    className="min-h-64 font-sans"
                  />
                  
                  <div className="space-y-2">
                    <Label>Комментарий</Label>
                    <Textarea
                      placeholder="Добавьте ваш комментарий..."
                      value={comment}
                      onChange={(e) => setComment(e.target.value)}
                      className="min-h-20"
                    />
                  </div>

                  <div className="flex gap-2">
                    <Button 
                      onClick={() => sendToChannel()}
                      disabled={isSending || !editedContent}
                      className="flex-1"
                    >
                      {isSending ? (
                        <Loader2 className="h-4 w-4 animate-spin mr-2" />
                      ) : (
                        <Send className="h-4 w-4 mr-2" />
                      )}
                      Опубликовать
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* History Tab */}
          <TabsContent value="history">
            <Card className="bg-white/90 backdrop-blur-sm">
              <CardHeader>
                <CardTitle>История рассылок</CardTitle>
                <CardDescription>
                  Ранее отправленные подборки
                </CardDescription>
              </CardHeader>
              <CardContent>
                {digests.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    История пуста
                  </div>
                ) : (
                  <div className="space-y-3">
                    {digests.map((digest) => (
                      <div 
                        key={digest.id}
                        className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                      >
                        <div>
                          <div className="font-medium">
                            {formatDate(digest.createdAt)}
                          </div>
                          <div className="text-sm text-gray-500">
                            {digest.isSent ? '✅ Отправлено' : '⏳ Ожидает'}
                            {digest.isPublished && ' • 📢 Опубликовано'}
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Badge variant={digest.isSent ? 'default' : 'secondary'}>
                            {digest.isSent ? 'Отправлено' : 'Черновик'}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="border-t bg-white/50 backdrop-blur-sm py-4 mt-8">
        <div className="max-w-6xl mx-auto px-4 text-center text-sm text-gray-500">
          🏠 Калининград Недвижимость Bot • Telegram Bot для ежедневной рассылки
        </div>
      </footer>
    </div>
  );
}

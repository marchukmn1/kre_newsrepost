import cron from 'node-cron';
import { sendDigestToChannel, getBotSettings, getBot, initWebhook, setBotCommands } from './telegram-service';
import { db } from '@/lib/db';

// Хранилище активных задач
const scheduledTasks = new Map<string, cron.ScheduledTask>();

/**
 * Инициализация планировщика
 */
export function initScheduler() {
  console.log('📅 Initializing scheduler...');
  
  // Проверяем настройки каждую минуту для обновления расписания
  cron.schedule('* * * * *', async () => {
    await checkAndUpdateSchedule();
  });
  
  // Запускаем начальную проверку
  checkAndUpdateSchedule();
}

/**
 * Проверка и обновление расписания
 */
async function checkAndUpdateSchedule() {
  const settings = await getBotSettings();
  
  if (!settings?.isActive) {
    // Останавливаем все задачи если бот неактивен
    stopAllTasks();
    return;
  }
  
  const taskId = `daily-${settings.sendTime}`;
  
  // Если задача уже существует с тем же временем - пропускаем
  if (scheduledTasks.has(taskId)) {
    return;
  }
  
  // Останавливаем старые задачи
  stopAllTasks();
  
  // Парсим время отправки
  const [hours, minutes] = settings.sendTime.split(':').map(Number);
  
  // Создаём cron выражение для указанного времени по Калининграду
  // Cron: minute hour day-of-month month day-of-week
  const cronExpression = `${minutes} ${hours} * * *`;
  
  console.log(`📅 Scheduling daily digest at ${settings.sendTime} (${settings.timezone})`);
  
  // Создаём задачу
  const task = cron.schedule(cronExpression, async () => {
    await sendScheduledDigest();
  }, {
    timezone: settings.timezone || 'Europe/Kaliningrad'
  });
  
  scheduledTasks.set(taskId, task);
}

/**
 * Отправка запланированного дайджеста
 */
async function sendScheduledDigest() {
  console.log('⏰ Scheduled time reached - sending digest...');
  
  const settings = await getBotSettings();
  
  if (!settings?.isActive || !settings.channelId) {
    console.log('⚠️ Bot inactive or channel not configured');
    return;
  }
  
  // Проверяем, не отправляли ли уже сегодня
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  const todayDigest = await db.dailyDigest.findFirst({
    where: {
      sentAt: {
        gte: today
      },
      channelId: settings.channelId
    }
  });
  
  if (todayDigest) {
    console.log('ℹ️ Digest already sent today');
    return;
  }
  
  // Отправляем дайджест
  const result = await sendDigestToChannel();
  
  if (result.success) {
    console.log('✅ Scheduled digest sent successfully');
  } else {
    console.error('❌ Failed to send scheduled digest:', result.error);
  }
}

/**
 * Остановка всех задач
 */
function stopAllTasks() {
  for (const [id, task] of scheduledTasks) {
    task.stop();
    scheduledTasks.delete(id);
  }
}

/**
 * Ручная отправка дайджеста
 */
export async function sendManualDigest(content?: string) {
  return await sendDigestToChannel(content);
}

/**
 * Получение следующего времени отправки
 */
export function getNextSendTime(): Date | null {
  const settings = getBotSettings();
  
  // Это будет обновлено асинхронно
  return null;
}

/**
 * Остановка планировщика
 */
export function stopScheduler() {
  stopAllTasks();
  console.log('📅 Scheduler stopped');
}

// Экспорт для использования в API
export const scheduler = {
  init: initScheduler,
  stop: stopScheduler,
  sendManual: sendManualDigest
};

import { Bot, Context, GrammyError, HttpError } from 'grammy';
import { db } from '@/lib/db';
import { newsService } from './news-service';

// Типы для настроек бота
interface BotConfig {
  botToken: string;
  channelId?: string;
  channelName?: string;
}

// Состояние редактирования
interface EditState {
  messageId: number;
  chatId: number;
  originalContent: string;
  editedContent: string;
  comment: string;
}

// Хранилище состояний (в памяти, для простоты)
const editStates = new Map<string, EditState>();

let botInstance: Bot | null = null;

/**
 * Получение или создание экземпляра бота
 */
export async function getBot(token?: string): Promise<Bot | null> {
  if (botInstance) return botInstance;
  
  const settings = await getBotSettings();
  const botToken = token || settings?.botToken;
  
  if (!botToken) {
    console.log('Bot token not configured');
    return null;
  }

  botInstance = new Bot(botToken);
  
  // Регистрация обработчиков
  registerHandlers(botInstance);
  
  return botInstance;
}

/**
 * Регистрация обработчиков команд
 */
function registerHandlers(bot: Bot) {
  // Команда /start
  bot.command('start', async (ctx) => {
    const userId = ctx.from?.id;
    const userName = ctx.from?.first_name || 'Пользователь';
    
    await ctx.reply(
      `👋 Привет, ${userName}!\n\n` +
      `🏠 Я бот для ежедневной подборки новостей о недвижимости в Калининграде.\n\n` +
      `📊 Команды:\n` +
      `/digest - Получить сегодняшнюю подборку\n` +
      `/settings - Настройки бота\n` +
      `/help - Справка\n\n` +
      `⏰ Каждый день в 8:00 я отправляю свежие новости!`
    );
  });

  // Команда /help
  bot.command('help', async (ctx) => {
    await ctx.reply(
      `🏠 <b>Бот недвижимости Калининграда</b>\n\n` +
      `Команды:\n` +
      `/start - Начать работу\n` +
      `/digest - Получить подборку новостей\n` +
      `/news - Искать новости вручную\n` +
      `/fact - Интересный факт о недвижимости\n` +
      `/settings - Настройки канала\n` +
      `/setchannel - Установить канал для публикации\n` +
      `/edit - Режим редактирования\n` +
      `/publish - Опубликовать в канал\n` +
      `/help - Эта справка\n\n` +
      `💡 Для перепубликации с редактированием:\n` +
      `1. Отправьте /edit\n` +
      `2. Отредактируйте текст\n` +
      `3. Добавьте комментарий\n` +
      `4. Отправьте /publish`,
      { parse_mode: 'HTML' }
    );
  });

  // Команда /digest - получить подборку
  bot.command('digest', async (ctx) => {
    await ctx.reply('🔍 Собираю свежие новости о недвижимости...');
    
    try {
      const digest = await generateDailyDigest();
      await ctx.reply(digest, { 
        parse_mode: 'HTML',
        disable_web_page_preview: true 
      });
    } catch (error) {
      console.error('Error generating digest:', error);
      await ctx.reply('❌ Произошла ошибка при генерации подборки. Попробуйте позже.');
    }
  });

  // Команда /news - поиск новостей
  bot.command('news', async (ctx) => {
    const args = ctx.message?.text?.split(' ').slice(1).join(' ');
    
    await ctx.reply('🔍 Ищу новости о недвижимости...');
    
    try {
      const news = await newsService.searchRealEstateNews(5);
      
      if (news.length === 0) {
        await ctx.reply('😕 Не удалось найти свежие новости. Попробуйте позже.');
        return;
      }

      let message = `📰 <b>Свежие новости недвижимости:</b>\n\n`;
      
      news.forEach((item, i) => {
        message += `<b>${i + 1}. ${item.title}</b>\n`;
        message += `${item.summary}\n`;
        message += `<a href="${item.source}">🔗 ${item.sourceName}</a>\n\n`;
      });

      await ctx.reply(message, { 
        parse_mode: 'HTML',
        disable_web_page_preview: true 
      });
    } catch (error) {
      console.error('Error searching news:', error);
      await ctx.reply('❌ Ошибка поиска. Попробуйте позже.');
    }
  });

  // Команда /fact - факт о недвижимости
  bot.command('fact', async (ctx) => {
    await ctx.reply('💡 Генерирую интересный факт...');
    
    try {
      const fact = await newsService.generateRealEstateFact();
      await ctx.reply(`💡 <b>Факт о недвижимости:</b>\n\n${fact}`, { parse_mode: 'HTML' });
    } catch (error) {
      console.error('Error generating fact:', error);
      await ctx.reply('❌ Не удалось сгенерировать факт. Попробуйте позже.');
    }
  });

  // Команда /setchannel - установка канала
  bot.command('setchannel', async (ctx) => {
    const args = ctx.message?.text?.split(' ').slice(1).join(' ');
    
    if (!args) {
      await ctx.reply(
        `📺 Для установки канала:\n\n` +
        `1. Добавьте бота в администраторы канала\n` +
        `2. Отправьте /setchannel @username_канала\n\n` +
        `Пример: /setchannel @my_real_estate_channel`
      );
      return;
    }

    // Извлекаем username канала
    let channelUsername = args.trim();
    if (!channelUsername.startsWith('@')) {
      channelUsername = '@' + channelUsername;
    }

    try {
      // Проверяем, что бот может писать в канал
      const chat = await ctx.api.getChat(channelUsername);
      
      // Сохраняем настройки
      await db.botSettings.upsert({
        where: { id: 'default' },
        update: {
          channelId: chat.id.toString(),
          channelName: chat.title || channelUsername,
          channelUsername: channelUsername
        },
        create: {
          id: 'default',
          botToken: '',
          channelId: chat.id.toString(),
          channelName: chat.title || channelUsername,
          channelUsername: channelUsername
        }
      });

      await ctx.reply(
        `✅ Канал установлен!\n\n` +
        `📺 ${chat.title || channelUsername}\n` +
        `🆔 ${chat.id}\n\n` +
        `Теперь вы можете публиковать туда подборки командой /publish`
      );
    } catch (error) {
      console.error('Error setting channel:', error);
      await ctx.reply(
        `❌ Не удалось установить канал.\n\n` +
        `Убедитесь что:\n` +
        `• Бот добавлен в администраторы канала\n` +
        `• У бота есть права публиковать сообщения\n` +
        `• Username канала указан верно`
      );
    }
  });

  // Команда /settings - показать настройки
  bot.command('settings', async (ctx) => {
    const settings = await getBotSettings();
    
    if (!settings) {
      await ctx.reply('⚙️ Настройки не сконфигурированы. Используйте /setchannel для установки канала.');
      return;
    }

    await ctx.reply(
      `⚙️ <b>Настройки бота:</b>\n\n` +
      `📺 Канал: ${settings.channelName || 'Не установлен'}\n` +
      `🆔 Channel ID: ${settings.channelId || 'Не установлен'}\n` +
      `⏰ Время отправки: ${settings.sendTime}\n` +
      `🌍 Часовой пояс: ${settings.timezone}\n` +
      `✅ Активен: ${settings.isActive ? 'Да' : 'Нет'}`,
      { parse_mode: 'HTML' }
    );
  });

  // Команда /publish - публикация в канал
  bot.command('publish', async (ctx) => {
    const settings = await getBotSettings();
    
    if (!settings?.channelId) {
      await ctx.reply('❌ Канал не настроен. Используйте /setchannel');
      return;
    }

    await ctx.reply('📝 Генерирую подборку для публикации...');

    try {
      const digest = await generateDailyDigest();
      
      // Сохраняем в базу
      const savedDigest = await db.dailyDigest.create({
        data: {
          content: digest,
          channelId: settings.channelId
        }
      });

      // Отправляем в канал
      const message = await bot.api.sendMessage(
        settings.channelId,
        digest,
        { 
          parse_mode: 'HTML',
          disable_web_page_preview: true 
        }
      );

      // Обновляем статус
      await db.dailyDigest.update({
        where: { id: savedDigest.id },
        data: {
          messageId: message.message_id.toString(),
          isSent: true,
          sentAt: new Date()
        }
      });

      await ctx.reply(
        `✅ Подборка опубликована!\n\n` +
        `📺 Канал: ${settings.channelName}\n` +
        `🔗 Сообщение: ${message.message_id}`
      );
    } catch (error) {
      console.error('Error publishing to channel:', error);
      await ctx.reply('❌ Ошибка публикации. Проверьте права бота в канале.');
    }
  });

  // Команда /edit - редактирование перед публикацией
  bot.command('edit', async (ctx) => {
    const userId = ctx.from?.id?.toString();
    if (!userId) return;

    await ctx.reply('📝 Генерирую подборку для редактирования...');

    try {
      const digest = await generateDailyDigest();
      
      // Сохраняем состояние
      editStates.set(userId, {
        messageId: 0,
        chatId: ctx.chat!.id,
        originalContent: digest,
        editedContent: digest,
        comment: ''
      });

      await ctx.reply(
        `📝 <b>Режим редактирования:</b>\n\n` +
        `${digest}\n\n` +
        `---\n\n` +
        `Отправьте новый текст или используйте:\n` +
        `• /comment <текст> - добавить комментарий\n` +
        `• /preview - предпросмотр\n` +
        `• /publish - опубликовать\n` +
        `• /cancel - отменить`,
        { 
          parse_mode: 'HTML',
          disable_web_page_preview: true 
        }
      );
    } catch (error) {
      console.error('Error in edit mode:', error);
      await ctx.reply('❌ Ошибка генерации. Попробуйте позже.');
    }
  });

  // Команда /comment - добавить комментарий
  bot.command('comment', async (ctx) => {
    const userId = ctx.from?.id?.toString();
    if (!userId) return;

    const state = editStates.get(userId);
    if (!state) {
      await ctx.reply('❌ Сначала используйте /edit');
      return;
    }

    const comment = ctx.message?.text?.split(' ').slice(1).join(' ');
    if (!comment) {
      await ctx.reply('📝 Использование: /comment <ваш комментарий>');
      return;
    }

    state.comment = comment;
    editStates.set(userId, state);

    await ctx.reply(`✅ Комментарий добавлен: "${comment}"\n\nИспользуйте /preview для предпросмотра или /publish для публикации.`);
  });

  // Команда /preview - предпросмотр
  bot.command('preview', async (ctx) => {
    const userId = ctx.from?.id?.toString();
    if (!userId) return;

    const state = editStates.get(userId);
    if (!state) {
      await ctx.reply('❌ Сначала используйте /edit');
      return;
    }

    let preview = state.editedContent;
    if (state.comment) {
      preview += `\n\n💬 <b>Комментарий:</b>\n${state.comment}`;
    }

    await ctx.reply(
      `👁 <b>Предпросмотр:</b>\n\n${preview}`,
      { 
        parse_mode: 'HTML',
        disable_web_page_preview: true 
      }
    );
  });

  // Команда /cancel - отмена редактирования
  bot.command('cancel', async (ctx) => {
    const userId = ctx.from?.id?.toString();
    if (!userId) return;

    editStates.delete(userId);
    await ctx.reply('❌ Редактирование отменено.');
  });

  // Обработка текстовых сообщений в режиме редактирования
  bot.on('message:text', async (ctx) => {
    const userId = ctx.from?.id?.toString();
    if (!userId) return;

    const state = editStates.get(userId);
    if (!state) return; // Не в режиме редактирования

    // Игнорируем команды
    if (ctx.message.text.startsWith('/')) return;

    // Обновляем контент
    state.editedContent = ctx.message.text;
    editStates.set(userId, state);

    await ctx.reply(
      '✅ Текст обновлён!\n\n' +
      'Используйте /preview для предпросмотра или /publish для публикации.'
    );
  });

  // Обработка ошибок
  bot.catch((err) => {
    const ctx = err.ctx;
    console.error(`Error while handling update ${ctx.update.update_id}:`);
    const e = err.error;
    if (e instanceof GrammyError) {
      console.error('Error in request:', e.description);
    } else if (e instanceof HttpError) {
      console.error('Could not contact Telegram:', e);
    } else {
      console.error('Unknown error:', e);
    }
  });
}

/**
 * Получение настроек бота из БД
 */
export async function getBotSettings() {
  try {
    return await db.botSettings.findFirst();
  } catch (error) {
    console.error('Error getting bot settings:', error);
    return null;
  }
}

/**
 * Сохранение настроек бота
 */
export async function saveBotSettings(settings: {
  botToken: string;
  channelId?: string;
  channelName?: string;
  channelUsername?: string;
  isActive?: boolean;
  sendTime?: string;
  timezone?: string;
}) {
  return await db.botSettings.upsert({
    where: { id: 'default' },
    update: settings,
    create: {
      id: 'default',
      ...settings
    }
  });
}

/**
 * Генерация ежедневной подборки
 */
export async function generateDailyDigest(): Promise<string> {
  // Ищем новости
  const news = await newsService.searchRealEstateNews(10);
  
  // Генерируем факт дня
  const fact = await newsService.generateRealEstateFact();
  
  // Генерируем вступление
  const intro = await newsService.generateDigestSummary(news);
  
  // Формируем сообщение
  return newsService.formatDigestMessage(intro, news, fact, new Date());
}

/**
 * Отправка подборки в канал
 */
export async function sendDigestToChannel(digestContent?: string): Promise<{ success: boolean; messageId?: string; error?: string }> {
  const bot = await getBot();
  const settings = await getBotSettings();
  
  if (!bot || !settings?.channelId) {
    return { success: false, error: 'Bot or channel not configured' };
  }

  try {
    const content = digestContent || await generateDailyDigest();
    
    // Сохраняем в базу
    const savedDigest = await db.dailyDigest.create({
      data: {
        content: content,
        channelId: settings.channelId
      }
    });

    // Отправляем
    const message = await bot.api.sendMessage(
      settings.channelId,
      content,
      { 
        parse_mode: 'HTML',
        disable_web_page_preview: true 
      }
    );

    // Обновляем статус
    await db.dailyDigest.update({
      where: { id: savedDigest.id },
      data: {
        messageId: message.message_id.toString(),
        isSent: true,
        sentAt: new Date()
      }
    });

    return { success: true, messageId: message.message_id.toString() };
  } catch (error) {
    console.error('Error sending digest:', error);
    return { success: false, error: String(error) };
  }
}

/**
 * Инициализация webhook
 */
export async function initWebhook(webhookUrl: string): Promise<boolean> {
  const bot = await getBot();
  if (!bot) return false;

  try {
    await bot.api.setWebhook(webhookUrl, {
      allowed_updates: ['message', 'callback_query', 'inline_query']
    });
    console.log('Webhook set:', webhookUrl);
    return true;
  } catch (error) {
    console.error('Error setting webhook:', error);
    return false;
  }
}

/**
 * Обработка webhook запроса
 */
export async function handleWebhook(body: any): Promise<void> {
  const bot = await getBot();
  if (!bot) return;

  try {
    await bot.handleUpdate(body);
  } catch (error) {
    console.error('Error handling webhook:', error);
  }
}

/**
 * Установка команд бота
 */
export async function setBotCommands(): Promise<void> {
  const bot = await getBot();
  if (!bot) return;

  await bot.api.setMyCommands([
    { command: 'start', description: 'Начать работу с ботом' },
    { command: 'digest', description: 'Получить подборку новостей' },
    { command: 'news', description: 'Поиск новостей о недвижимости' },
    { command: 'fact', description: 'Интересный факт о недвижимости' },
    { command: 'setchannel', description: 'Установить канал для публикации' },
    { command: 'settings', description: 'Показать настройки' },
    { command: 'edit', description: 'Редактировать подборку' },
    { command: 'publish', description: 'Опубликовать в канал' },
    { command: 'help', description: 'Справка по командам' }
  ]);
}

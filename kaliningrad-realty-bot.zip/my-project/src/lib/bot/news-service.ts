import ZAI from 'z-ai-web-dev-sdk';

export interface NewsSearchResult {
  title: string;
  summary: string;
  source: string;
  sourceName: string;
  category: 'news' | 'fact' | 'announcement';
  publishedAt: Date;
}

// Ключевые слова для поиска недвижимости в Калининграде
const SEARCH_QUERIES = [
  'недвижимость Калининград новости',
  'квартиры Калининград цены',
  'жилье Калининград рынок',
  'новостройки Калининград',
  'аренда квартир Калининград',
  'ипотека Калининград',
  'земельные участки Калининград',
  'коммерческая недвижимость Калининград',
];

export class NewsService {
  private zai: Awaited<ReturnType<typeof ZAI.create>> | null = null;

  async initialize() {
    if (!this.zai) {
      this.zai = await ZAI.create();
    }
    return this.zai;
  }

  /**
   * Поиск новостей о недвижимости в Калининграде
   */
  async searchRealEstateNews(count: number = 10): Promise<NewsSearchResult[]> {
    await this.initialize();
    
    const allResults: NewsSearchResult[] = [];
    
    // Выбираем случайные запросы для разнообразия
    const shuffledQueries = [...SEARCH_QUERIES].sort(() => Math.random() - 0.5).slice(0, 3);
    
    for (const query of shuffledQueries) {
      try {
        const results = await this.zai!.functions.invoke('web_search', {
          query: `${query} 2024 2025`,
          num: 10,
          recency_days: 7 // Новости за последнюю неделю
        });

        for (const item of results) {
          // Фильтруем релевантные результаты
          if (this.isRelevantNews(item)) {
            allResults.push({
              title: item.name,
              summary: this.cleanSummary(item.snippet),
              source: item.url,
              sourceName: item.host_name,
              category: this.detectCategory(item),
              publishedAt: new Date(item.date || Date.now())
            });
          }
        }
      } catch (error) {
        console.error(`Error searching for "${query}":`, error);
      }
    }

    // Убираем дубликаты по заголовку
    const uniqueResults = this.removeDuplicates(allResults);
    
    // Сортируем по дате и берём топ count
    return uniqueResults
      .sort((a, b) => b.publishedAt.getTime() - a.publishedAt.getTime())
      .slice(0, count);
  }

  /**
   * Генерация интересного факта о недвижимости с помощью AI
   */
  async generateRealEstateFact(): Promise<string> {
    await this.initialize();

    const completion = await this.zai!.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'Ты эксперт по недвижимости в Калининграде и Калининградской области. Твоя задача - генерировать интересные и полезные факты о рынке недвижимости, архитектуре, районах города, ценах и трендах. Отвечай кратко, но информативно (2-3 предложения).'
        },
        {
          role: 'user',
          content: 'Сгенерируй один интересный факт о недвижимости в Калининграде. Это может быть информация о рынке, архитектуре, истории зданий, интересных районах или трендах цен.'
        }
      ],
      temperature: 0.8,
      max_tokens: 200
    });

    return completion.choices[0]?.message?.content || 'Интересный факт о недвижимости Калининграда скоро появится...';
  }

  /**
   * Генерация текста подборки с помощью AI
   */
  async generateDigestSummary(newsItems: NewsSearchResult[]): Promise<string> {
    await this.initialize();

    const newsText = newsItems
      .map((item, i) => `${i + 1}. ${item.title}\n${item.summary}`)
      .join('\n\n');

    const completion = await this.zai!.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'Ты редактор новостной рассылки о недвижимости в Калининграде. Твоя задача - составить краткое вступление к ежедневной подборке новостей. Будь краток (1-2 предложения) и дружелюбен. Используй эмодзи для привлекательности.'
        },
        {
          role: 'user',
          content: `Составь краткое вступление к подборке из ${newsItems.length} новостей о недвижимости в Калининграде за сегодня.\n\nНовости:\n${newsText}`
        }
      ],
      temperature: 0.7,
      max_tokens: 150
    });

    return completion.choices[0]?.message?.content || '🏠 Доброе утро! Вот свежая подборка новостей о недвижимости в Калининграде:';
  }

  /**
   * Формирование полного текста подборки
   */
  formatDigestMessage(
    intro: string, 
    newsItems: NewsSearchResult[], 
    fact: string,
    date: Date
  ): string {
    const dateStr = date.toLocaleDateString('ru-RU', { 
      weekday: 'long', 
      day: 'numeric', 
      month: 'long' 
    });

    let message = `🏠 <b>Недвижимость Калининграда</b>\n`;
    message += `📅 ${dateStr.charAt(0).toUpperCase() + dateStr.slice(1)}\n\n`;
    message += `${intro}\n\n`;
    
    // Добавляем новости
    for (let i = 0; i < newsItems.length; i++) {
      const item = newsItems[i];
      const categoryEmoji = this.getCategoryEmoji(item.category);
      
      message += `${categoryEmoji} <b>${i + 1}. ${this.escapeHtml(item.title)}</b>\n`;
      message += `${this.escapeHtml(item.summary)}\n`;
      message += `<a href="${item.source}">🔗 ${item.sourceName}</a>\n\n`;
    }

    // Добавляем факт дня
    message += `💡 <b>Факт дня:</b>\n${this.escapeHtml(fact)}\n\n`;
    
    message += `---\n`;
    message += `🤖 <i>Подготовлено ботом @KaliningradRealtyBot</i>`;

    return message;
  }

  /**
   * Проверка релевантности новости
   */
  private isRelevantNews(item: { name: string; snippet: string; host_name: string }): boolean {
    const text = `${item.name} ${item.snippet}`.toLowerCase();
    
    // Ключевые слова для релевантности
    const relevantKeywords = [
      'недвижимость', 'квартир', 'жиль', 'дом', 'домашн',
      'покупк', 'продаж', 'аренд', 'ипотек', 'цен',
      'застройщик', 'новостро', 'вторичк', 'рынок',
      'калининград', 'область', 'регион',
      'квадратный метр', 'кв.м', 'кв м',
      'площадь', 'район', 'жк ', 'жилой комплекс'
    ];

    // Исключаем нерелевантные
    const excludeKeywords = [
      'ваканси', 'резюме', 'работа', 'ищу',
      'порно', 'секс', 'интим'
    ];

    const hasRelevant = relevantKeywords.some(kw => text.includes(kw));
    const hasExclude = excludeKeywords.some(kw => text.includes(kw));

    return hasRelevant && !hasExclude && item.snippet.length > 50;
  }

  /**
   * Определение категории новости
   */
  private detectCategory(item: { name: string; snippet: string }): 'news' | 'fact' | 'announcement' {
    const text = `${item.name} ${item.snippet}`.toLowerCase();
    
    if (text.includes('объявлен') || text.includes('старт') || text.includes('открыт')) {
      return 'announcement';
    }
    if (text.includes('факт') || text.includes('интересн') || text.includes('удивит')) {
      return 'fact';
    }
    return 'news';
  }

  /**
   * Очистка текста summary
   */
  private cleanSummary(summary: string): string {
    return summary
      .replace(/\s+/g, ' ')
      .trim()
      .slice(0, 300); // Ограничиваем длину
  }

  /**
   * Удаление дубликатов по заголовку
   */
  private removeDuplicates(results: NewsSearchResult[]): NewsSearchResult[] {
    const seen = new Set<string>();
    return results.filter(item => {
      const normalized = item.title.toLowerCase().slice(0, 50);
      if (seen.has(normalized)) {
        return false;
      }
      seen.add(normalized);
      return true;
    });
  }

  /**
   * Эмодзи для категории
   */
  private getCategoryEmoji(category: string): string {
    const emojis: Record<string, string> = {
      news: '📰',
      fact: '📊',
      announcement: '📢'
    };
    return emojis[category] || '📰';
  }

  /**
   * Экранирование HTML для Telegram
   */
  private escapeHtml(text: string): string {
    return text
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }
}

// Singleton instance
export const newsService = new NewsService();
